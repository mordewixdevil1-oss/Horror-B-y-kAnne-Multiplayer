extends Node3D

var player: CharacterBody3D
var keys := 0
var status: Label
var granny: Node3D
var exit_door: StaticBody3D
var mobile_look := false
var last_touch := Vector2.ZERO

func _ready():
    _build_world()
    _build_player()
    _build_granny()
    _build_ui()

func _build_world():
    var env = WorldEnvironment.new()
    var e = Environment.new()
    e.background_mode = Environment.BG_SKY
    e.ambient_light_source = Environment.SOURCE_COLOR
    e.ambient_light_color = Color(0.22, 0.22, 0.27)
    e.ambient_light_energy = 0.55
    env.environment = e
    add_child(env)

    var light = DirectionalLight3D.new()
    light.rotation_degrees = Vector3(-48, -32, 0)
    light.light_energy = 0.35
    add_child(light)

    _box("Floor", Vector3(0,-0.25,0), Vector3(18,0.5,18), Color(0.19,0.17,0.15))
    _box("Ceiling", Vector3(0,4.2,0), Vector3(18,0.3,18), Color(0.12,0.11,0.1))
    _box("BackWall", Vector3(0,2,-9), Vector3(18,4.5,0.3), Color(0.24,0.21,0.19))
    _box("LeftWall", Vector3(-9,2,0), Vector3(0.3,4.5,18), Color(0.22,0.2,0.18))
    _box("RightWall", Vector3(9,2,0), Vector3(0.3,4.5,18), Color(0.22,0.2,0.18))
    _box("FrontLeft", Vector3(-6.5,2,9), Vector3(5,4.5,0.3), Color(0.22,0.2,0.18))
    _box("FrontRight", Vector3(6.5,2,9), Vector3(5,4.5,0.3), Color(0.22,0.2,0.18))
    _box("DoorTop", Vector3(0,3.8,9), Vector3(8,0.5,0.3), Color(0.22,0.2,0.18))
    # Inner partitions and furniture-like obstacles
    _box("Partition1", Vector3(-3,1.5,-2), Vector3(0.25,3,7), Color(0.27,0.23,0.2))
    _box("Partition2", Vector3(3,1.5,2), Vector3(0.25,3,7), Color(0.27,0.23,0.2))
    _box("Table", Vector3(0,0.9,1), Vector3(2.8,1.8,1.3), Color(0.12,0.1,0.09))
    _box("Cabinet", Vector3(-6,1.1,-5), Vector3(1.5,2.2,1), Color(0.16,0.1,0.07))
    # Three colored key pickups
    _pickup(Vector3(-6,0.5,3), Color.GOLD, "Sarı anahtar")
    _pickup(Vector3(5,0.5,-5), Color.DEEP_SKY_BLUE, "Mavi anahtar")
    _pickup(Vector3(0,0.5,-7), Color.RED, "Kırmızı anahtar")
    exit_door = _make_box_body("FrontExit", Vector3(0,1.7,8.8), Vector3(2.2,3.4,0.25), Color(0.12,0.07,0.04))

func _box(n:String, pos:Vector3, size:Vector3, color:Color):
    var body = StaticBody3D.new()
    body.name = n
    body.position = pos
    var mesh = MeshInstance3D.new()
    var bm = BoxMesh.new()
    bm.size = size
    mesh.mesh = bm
    var mat = StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 1.0
    mesh.material_override = mat
    body.add_child(mesh)
    var shape = CollisionShape3D.new()
    var bs = BoxShape3D.new()
    bs.size = size
    shape.shape = bs
    body.add_child(shape)
    add_child(body)
    return body

func _make_box_body(n:String, pos:Vector3, size:Vector3, color:Color):
    return _box(n,pos,size,color)

func _pickup(pos:Vector3, color:Color, label:String):
    var area = Area3D.new()
    area.position = pos
    area.set_meta("pickup_name", label)
    var mesh = MeshInstance3D.new()
    var sm = SphereMesh.new()
    sm.radius = 0.22
    sm.height = 0.44
    mesh.mesh = sm
    var mat = StandardMaterial3D.new()
    mat.albedo_color = color
    mat.emission_enabled = true
    mat.emission = color * 0.35
    mesh.material_override = mat
    area.add_child(mesh)
    var cs = CollisionShape3D.new()
    var sphere = SphereShape3D.new()
    sphere.radius = 0.65
    cs.shape = sphere
    area.add_child(cs)
    area.body_entered.connect(func(body):
        if body == player:
            keys += 1
            status.text = "Anahtar: %d/3  |  %s alındı" % [keys, label]
            area.queue_free()
    )
    add_child(area)

func _build_player():
    player = CharacterBody3D.new()
    player.position = Vector3(0,1,5)
    var col = CollisionShape3D.new()
    var capsule = CapsuleShape3D.new()
    capsule.radius = 0.35
    capsule.height = 1.7
    col.shape = capsule
    player.add_child(col)
    var cam = Camera3D.new()
    cam.position.y = 0.55
    cam.current = true
    player.add_child(cam)
    player.set_script(load("res://scripts/player.gd"))
    add_child(player)

func _build_granny():
    granny = Node3D.new()
    granny.position = Vector3(0,0,-4)
    var body = MeshInstance3D.new()
    var capsule = CapsuleMesh.new()
    capsule.radius = 0.48
    capsule.height = 1.8
    body.mesh = capsule
    var skin = StandardMaterial3D.new()
    skin.albedo_color = Color(0.62,0.58,0.52)
    body.material_override = skin
    body.position.y = 0.9
    granny.add_child(body)
    var head = MeshInstance3D.new()
    var sphere = SphereMesh.new()
    sphere.radius = 0.38
    head.mesh = sphere
    head.position.y = 1.95
    var hm = StandardMaterial3D.new()
    hm.albedo_color = Color(0.72,0.66,0.58)
    head.material_override = hm
    granny.add_child(head)
    add_child(granny)

func _build_ui():
    var layer = CanvasLayer.new()
    var panel = ColorRect.new()
    panel.color = Color(0,0,0,0.55)
    panel.position = Vector2(12,12)
    panel.size = Vector2(470,64)
    layer.add_child(panel)
    status = Label.new()
    status.position = Vector2(25,25)
    status.text = "Horror Büyükanne | Anahtar: 0/3"
    status.add_theme_font_size_override("font_size",22)
    layer.add_child(status)
    var help = Label.new()
    help.position = Vector2(18,85)
    help.text = "Hareket: WASD / dokunmatik joystick alanı  •  Kaçış: ön kapı"
    help.add_theme_font_size_override("font_size",16)
    layer.add_child(help)
    add_child(layer)

func _process(delta):
    if is_instance_valid(granny) and is_instance_valid(player):
        var target = player.global_position
        target.y = 0
        var here = granny.global_position
        here.y = 0
        if here.distance_to(target) > 1.4:
            granny.global_position = granny.global_position.move_toward(Vector3(target.x,0,target.z), delta*0.85)
            granny.look_at(Vector3(target.x,1,target.z), Vector3.UP)
    if player and player.global_position.z > 8.0 and abs(player.global_position.x) < 1.3:
        if keys >= 3:
            status.text = "KAPI AÇILDI! KAÇTIN!  •  KOK Games"
        else:
            status.text = "Kapı kilitli! 3 anahtarı da bul (%d/3)" % keys
            player.global_position.z = 7.4
